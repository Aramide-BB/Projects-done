#converts a numeric score to a string label 
def quality_label(score):
    if score >= 85:
        return "Excellent"
    elif score >= 70:
        return "Good"
    elif score >= 50:
        return "Fair"
    return "Poor"

#normalizes a given score to a 0 - 100 scale
def normalize_quality(score, current_max = 100):
    normalized_quality = (score / current_max) * 100
    return round(normalized_quality,2)
    
#computes a combined sleep score (0 - 100 scale)
def compute_sleep_score(duration, quality_score):
    score = min(duration/8.0,1.0) * 60 + quality_score * 0.4
    return round(min(score,100),2)