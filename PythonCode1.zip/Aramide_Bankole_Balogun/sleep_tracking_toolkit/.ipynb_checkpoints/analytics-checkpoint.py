from sleep_tracking_toolkit.utils import compute_sleep_score

#returns the overall average sleep duration across all records
def overall_average_duration(records):
    if not records:
        return 0.00
    total_duration = sum(record.total_duration() for record in records)
    return round(total_duration / len(records), 2)
    
    
#returns the date of the record with the highest average sleep score
def best_sleep_day(records):
    if not records:
        return None
    best_record = max(records, key=lambda record:record.average_sleep_score())
    return best_record.date
    
#returns a list of dates where any segment has duration below the threshold
def detect_under_sleep_days(records, threshold = 7):
    return [record.date for record in records if any (duration < threshold for duration, _ in record.segments)]

#checks whether the durations contain a sharp jump or drop between any two consecutive values   
def detect_spike(durations, threshold = 2):
    return any(abs(durations[i] - durations[i+1]) >= threshold for i in range(len(durations)))

#returns a list of 'up', 'down', or 'same' describing how the sleep duration changes in the list of durations
def duration_trend(durations):
    trend = []
    for i in range(1, len(durations)):
        if durations[i] > durations[i-1]:
            trend.append("up")
        elif durations[i] < durations[i-1]:
            trend.append("down")
        else:
            trend.append("same")
    return trend
    
#returns the average of all segment-level sleep scores
def average_sleep_score_across_days(records):
    scores = [compute_sleep_score(duration, quality) for record in records for duration, quality in record.segments]
    return round(sum(scores)/len(scores), 2) 
    

            