from sleep_tracking_toolkit.utils import quality_label, compute_sleep_score

class DailySleepRecord:
    def __init__(self, date, segments):
        self.date = date
        self.segments = segments
        
# returns the average of all quality scores, rounded to two decimal places  
    def average_quality(self):
        if not self.segments:
            return 0.00
        total_quality = sum(quality for _, quality in self.segments)
        return round(total_quality/ len(self.segments), 2)
        
# returns the sum of all sleep durations, rounded to two decimal places.
    def total_duration(self):
        if not self.segments:
            return 0.00
        total_time = sum(duration for duration, _ in self.segments)
        return round(total_time, 2)
         
#  returns True if all segments of the day meet both duration and quality thresholds      
    def is_restful(self, duration_threshold = 7, quality_threshold = 75):
        return all(duration >= duration_threshold and quality >= quality_threshold for duration, quality in self.segments)

# returns the average computed sleep score (using compute_sleep_score() in utils), rounded to two decimal places
    def average_sleep_score(self):
        scores = [compute_sleep_score(duration, quality) for duration, quality in self.segments]
        return round(sum(scores)/len(scores), 2) 
        
#  returns a dictionary with keys 'date', 'avg_quality', 'total_duration', 'avg_sleep_score', and 'quality_label'
    def summary(self):
        return{
            "date": self.date,
            "avg_quality": self.average_quality(),
            "total duration": self.total_duration(),
            "avg_sleep_score": self.average_sleep_score(),
            "quality_label": quality_label(self.average_quality())
        }
        
        
